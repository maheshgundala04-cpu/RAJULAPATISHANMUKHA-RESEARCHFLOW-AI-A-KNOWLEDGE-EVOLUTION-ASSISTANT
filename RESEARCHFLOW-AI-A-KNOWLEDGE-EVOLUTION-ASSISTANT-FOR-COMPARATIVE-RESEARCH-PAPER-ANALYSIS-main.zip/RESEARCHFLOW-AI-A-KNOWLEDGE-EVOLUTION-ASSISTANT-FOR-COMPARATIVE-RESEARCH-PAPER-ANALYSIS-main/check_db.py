<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ResearchFlow AI | Analyze. Compare. Evolve.</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Syne:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</head>
<body>
    <div class="app-container">
        <!-- Floating Particles Background -->
        <div id="particles-js" class="particles-container"></div>
        <div class="animate-bg-overlay"></div>

        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-mark">RF</div>
                    <div class="logo-text">
                        <span class="logo-title">ResearchFlow</span>
                        <span class="logo-sub">AI Memento</span>
                    </div>
                </div>
                <button id="toggleSidebar" class="mobile-only-btn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
                </button>
            </div>

            <div class="search-sidebar-wrapper">
                <input type="text" id="sidebarSearch" placeholder="Search mementos...">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            </div>

            <div class="sidebar-nav">
                <!-- Navigation moved to top nav -->
            </div>

            <div class="mementos-section">
                <div class="section-header">
                    <span>Recent Research</span>
                    <button id="refreshMementosBtn" class="refresh-icon" title="Refresh List">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
                    </button>
                </div>
                <ul id="mementosList" class="mementos-list">
                    <!-- Items injected here -->
                </ul>
            </div>

            <div class="sidebar-footer">
                <button id="compareBtn" class="primary-btn compare-btn" disabled>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                    Compare Selection
                </button>
                <button id="logoutBtn" class="ghost-btn logout-btn">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                    Logout
                </button>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-nav">
                <div class="input-container glass">
                    <input type="url" id="urlInput" placeholder="Enter research paper or article URL...">
                    <button id="analyzeBtn" class="analyze-action-btn">
                        <span>Analyze</span>
                        <div class="btn-shine"></div>
                    </button>
                </div>

                <div class="header-tabs">
                    <button class="header-tab-btn active" id="navHome">📊 Dashboard</button>
                    <button class="header-tab-btn" id="navHelp">📘 User Guide</button>
                    <button class="header-tab-btn" id="navAbout">👨‍💻 About Devs</button>
                </div>
            </header>

            <div class="scroll-container" id="scrollContainer">
                <!-- Hero Section -->
                <section class="hero-section" id="heroSection">
                    <div class="hero-content">
                        <h1 class="animate-text">ResearchFlow AI</h1>
                        <p class="hero-subtitle">Analyze. Compare. Evolve.</p>
                        <div class="hero-stats">
                            <div class="stat-card glass animate-card">
                                <span class="stat-value" id="statTotalPapers">0</span>
                                <span class="stat-label">Papers Analyzed</span>
                            </div>
                            <div class="stat-card glass animate-card" style="animation-delay: 0.1s;">
                                <span class="stat-value" id="statRecentTitle">N/A</span>
                                <span class="stat-label">Latest Discovery</span>
                            </div>
                            <div class="stat-card glass animate-card" style="animation-delay: 0.2s;">
                                <span class="stat-value" id="statTotalWords">0</span>
                                <span class="stat-label">Insights Generated</span>
                            </div>
                        </div>
                    </div>
                    <div class="hero-visual">
                        <div class="research-illustration">
                            <div class="floating-element" style="left: 10%; animation-delay: 0s;">
                                <svg width="40" height="40" viewBox="0 0 24 24" fill="var(--primary)" opacity="0.4"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                            </div>
                            <div class="floating-element" style="right: 15%; animation-delay: 1s;">
                                <svg width="50" height="50" viewBox="0 0 24 24" fill="var(--accent)" opacity="0.3"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
                            </div>
                            <div class="floating-element" style="bottom: 10%; left: 30%; animation-delay: 2s;">
                                <svg width="30" height="30" viewBox="0 0 24 24" fill="var(--primary-dark)" opacity="0.2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                            </div>
                            <div class="typing-container" id="heroTyping">Analyze. Compare. Evolve.</div>
                        </div>
                    </div>
                </section>

                <div class="content-body">
                    <!-- Loading State -->
                    <div id="loadingState" class="loading-overlay hidden">
                        <div class="ai-loader">
                            <div class="loader-circle"></div>
                            <div class="loader-circle"></div>
                            <div class="loader-circle"></div>
                            <p>AI is analyzing the research...</p>
                        </div>
                        <div class="progress-container">
                            <div class="progress-bar" id="progressBar"></div>
                        </div>
                    </div>

                    <!-- Dashboard / Timeline / Results -->
                    <div id="dashboardView">
                        <!-- Timeline Section -->
                        <div class="section-title">
                            <h3>Research Timeline</h3>
                            <div class="title-line"></div>
                        </div>
                        <div class="timeline-container glass" id="timelineView">
                            <!-- Timeline items here -->
                            <div class="empty-timeline">No research papers in your timeline yet.</div>
                        </div>
                    </div>

                    <div id="resultsView" class="hidden">
                        <div class="results-header-actions">
                            <button id="backToDash" class="icon-text-btn">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
                                Dashboard
                            </button>
                            <h2 id="displayTitle">Paper Title</h2>
                            <a id="sourceLink" href="#" target="_blank" class="glass-link">
                                Source <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                            </a>
                        </div>

                        <div class="results-grid">
                            <!-- Summary Card -->
                            <div class="analysis-card glass reveal-on-scroll">
                                <div class="card-header">
                                    <div class="card-icon s-bg"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg></div>
                                    <h4>Summary</h4>
                                </div>
                                <div class="card-content" id="resSummary"></div>
                            </div>

                            <!-- Methodology Card -->
                            <div class="analysis-card glass reveal-on-scroll">
                                <div class="card-header">
                                    <div class="card-icon m-bg"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div>
                                    <h4>Methodology</h4>
                                </div>
                                <div class="card-content" id="resMethodology"></div>
                            </div>

                            <!-- Results Card -->
                            <div class="analysis-card glass reveal-on-scroll">
                                <div class="card-header">
                                    <div class="card-icon r-bg"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg></div>
                                    <h4>Results</h4>
                                </div>
                                <div class="card-content" id="resResults"></div>
                            </div>

                            <!-- Contributions Card -->
                            <div class="analysis-card glass reveal-on-scroll">
                                <div class="card-header">
                                    <div class="card-icon c-bg"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div>
                                    <h4>Contributions</h4>
                                </div>
                                <ul class="card-list" id="resContributions"></ul>
                            </div>

                            <!-- Evolution Card -->
                            <div class="analysis-card glass full-width reveal-on-scroll">
                                <div class="card-header">
                                    <div class="card-icon e-bg"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v10l4.5 4.5"/><circle cx="12" cy="12" r="10"/></svg></div>
                                    <h4>Evolutionary Context</h4>
                                </div>
                                <div class="card-content" id="resEvolution"></div>
                            </div>

                            <!-- Gaps Card -->
                            <div class="analysis-card glass full-width reveal-on-scroll">
                                <div class="card-header">
                                    <div class="card-icon g-bg"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
                                    <h4>Research Gaps</h4>
                                </div>
                                <div class="card-content" id="resGaps"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Comparison View -->
                    <div id="compareView" class="hidden">
                        <div class="results-header-actions">
                            <button id="backToDashCompare" class="icon-text-btn">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
                                Dashboard
                            </button>
                            <h2>Comparative Analysis</h2>
                        </div>
                        <div class="comparison-container">
                            <div id="compareContent" class="comparison-table">
                                <!-- Structured Comparison Columns Injected Here -->
                            </div>
                        </div>
                    </div>

                    <!-- Help View -->
                    <div id="helpView" class="hidden">
                        <div class="info-section">
                            <div class="info-card glass animate-pop">
                                <h3>🚀 How to Use ResearchFlow AI</h3>
                                <div class="info-grid">
                                    <div class="dev-profile">
                                        <div class="dev-avatar">1</div>
                                        <div>
                                            <strong>Enter URL</strong>
                                            <p>Paste any research paper or article URL in the top bar.</p>
                                        </div>
                                    </div>
                                    <div class="dev-profile">
                                        <div class="dev-avatar">2</div>
                                        <div>
                                            <strong>Analyze</strong>
                                            <p>Our AI extracts key insights, methodology, and gaps.</p>
                                        </div>
                                    </div>
                                    <div class="dev-profile">
                                        <div class="dev-avatar">3</div>
                                        <div>
                                            <strong>Compare</strong>
                                            <p>Select multiple papers from the sidebar to see differences.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- About View -->
                    <div id="aboutView" class="hidden">
                        <div class="info-section">
                            <div class="info-card glass animate-pop">
                                <h3>🎓 About ResearchFlow AI</h3>
                                <p>A Generative AI Course fulfillment project (2026) designed to streamline academic research synthesis.</p>
                                <div class="info-grid" style="margin-top: 30px;">
                                    <div class="dev-profile">
                                        <div class="dev-avatar">GP</div>
                                        <div><strong>P. Gopi Chand</strong><br>Lead Architect</div>
                                    </div>
                                    <div class="dev-profile">
                                        <div class="dev-avatar">VR</div>
                                        <div><strong>Ch. Vivekananda Reddy</strong><br>UI/UX Designer</div>
                                    </div>
                                    <div class="dev-profile">
                                        <div class="dev-avatar">NK</div>
                                        <div><strong>D. Balaiah</strong><br>Backend Engineer</div>
                                    </div>
                                    <div class="dev-profile">
                                        <div class="dev-avatar">BL</div>
                                        <div><strong>G. Nikhilesh</strong><br>Research Strategist</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <!-- AI Chatbot UI -->
        <div class="chatbot-container" id="chatbot">
            <button id="chatbotToggle" class="chatbot-trigger glass">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <span class="chat-badge hidden">!</span>
            </button>
            <div class="chatbot-window glass hidden" id="chatWindow">
                <div class="chat-header">
                    <div class="chat-title">
                        <div class="ai-status"></div>
                        <span>Research Assistant</span>
                    </div>
                    <button id="closeChat" class="close-btn">&times;</button>
                </div>
                <div class="chat-messages" id="chatMessages">
                    <div class="message system">
                        Hello! Select a paper and ask me anything about its methodology, results, or gaps.
                    </div>
                </div>
                <div class="chat-input-area">
                    <input type="text" id="chatInput" placeholder="Ask about this research...">
                    <button id="sendChatBtn">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polyline points="22 2 15 22 11 13 2 9 22 2"/></svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Modals -->
        <div id="duplicateModal" class="modal hidden">
            <div class="modal-content glass animate-pop">
                <div class="modal-icon warning">⚠️</div>
                <h3>Already Analyzed</h3>
                <p>This paper already exists in your library. Would you like to analyze it again to get fresh insights?</p>
                <div class="modal-actions">
                    <button id="cancelAnalyze" class="ghost-btn">Cancel</button>
                    <button id="confirmAnalyze" class="primary-btn">Analyze Again</button>
                </div>
            </div>
        </div>

        <div id="deleteModal" class="modal hidden">
            <div class="modal-content glass animate-pop">
                <div class="modal-icon danger">🗑️</div>
                <h3>Delete Memento?</h3>
                <p>Are you sure you want to remove this research from your library? This action cannot be undone.</p>
                <div class="modal-actions">
                    <button id="cancelDelete" class="ghost-btn">Cancel</button>
                    <button id="confirmDelete" class="danger-btn">Delete Permanently</button>
                </div>
            </div>
        </div>

        <!-- Error Modal -->
        <div id="errorModal" class="modal hidden">
            <div class="modal-content glass animate-pop">
                <div class="modal-icon warning">⚠️</div>
                <h3 id="errorModalTitle">System Message</h3>
                <p id="errorModalMessage">Something went wrong.</p>
                <div class="modal-actions">
                    <button id="closeErrorModal" class="primary-btn">Dismiss</button>
                </div>
            </div>
        </div>
        <!-- Analysis Progress Overlay -->
        <div id="loadingState" class="analysis-progress-overlay hidden">
            <div class="ai-loader">
                <div class="loader-circle"></div>
                <div class="loader-circle"></div>
                <div class="loader-circle"></div>
            </div>
            <div class="progress-status">Analyzing Research Paper...</div>
            <div class="progress-track">
                <div class="analysis-progress-bar"></div>
            </div>
        </div>
    </div>

    <script src="app.js"></script>
</body>
</html>